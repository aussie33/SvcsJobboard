#!/bin/bash
set -e

SERVER_IP="64.225.6.33"
SERVER_USER="root"

echo "Building and deploying to DigitalOcean..."

# Build Docker image
docker build -f Dockerfile.production -t career-portal:current .

# Save image
docker save career-portal:current | gzip > career-portal-current.tar.gz

# Create deployment package
tar -czf deploy-package.tar.gz \
    career-portal-current.tar.gz \
    docker-compose.yml \
    init-db.sql \
    nginx.conf \
    production-server.js

# Deploy to server
scp deploy-package.tar.gz $SERVER_USER@$SERVER_IP:/tmp/

ssh $SERVER_USER@$SERVER_IP << 'EOSSH'
    cd /tmp
    tar -xzf deploy-package.tar.gz
    
    mkdir -p /opt/career-portal-current
    cd /opt/career-portal-current
    
    # Copy files
    mv /tmp/docker-compose.yml ./
    mv /tmp/init-db.sql ./
    mv /tmp/nginx.conf ./
    mv /tmp/production-server.js ./
    
    # Install Docker if needed
    if ! command -v docker &> /dev/null; then
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        systemctl start docker
        systemctl enable docker
    fi
    
    # Install Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-linux-x86_64" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
    fi
    
    # Load image
    gunzip -c /tmp/career-portal-current.tar.gz | docker load
    
    # Stop existing containers
    docker-compose down --remove-orphans 2>/dev/null || true
    
    # Start services
    POSTGRES_PASSWORD="career_secure_password_2024" \
    SESSION_SECRET="career-portal-super-secret-key-production-2024" \
    docker-compose up -d
    
    sleep 30
    docker-compose ps
    
    # Cleanup
    rm -f /tmp/deploy-package.tar.gz /tmp/career-portal-current.tar.gz
    
    echo "Deployment completed!"
EOSSH

rm -f deploy-package.tar.gz career-portal-current.tar.gz

echo "Career Portal deployed successfully!"
echo "Access at: http://64.225.6.33"
