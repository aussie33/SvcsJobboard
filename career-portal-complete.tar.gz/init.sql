-- Create database if not exists
CREATE DATABASE IF NOT EXISTS career_portal;

-- Connect to the database
\c career_portal;

-- Create tables
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    full_name VARCHAR(100),
    role VARCHAR(20) DEFAULT 'applicant',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS jobs (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    department VARCHAR(100),
    category_id INTEGER REFERENCES categories(id),
    short_description TEXT,
    full_description TEXT,
    requirements TEXT,
    type VARCHAR(50) DEFAULT 'full-time',
    location VARCHAR(100) DEFAULT 'remote',
    salary_range VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    employee_id INTEGER REFERENCES users(id),
    posted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS job_tags (
    id SERIAL PRIMARY KEY,
    job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
    tag VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
    id SERIAL PRIMARY KEY,
    job_id INTEGER REFERENCES jobs(id),
    applicant_id INTEGER REFERENCES users(id),
    cover_letter TEXT,
    resume_filename VARCHAR(255),
    status VARCHAR(50) DEFAULT 'submitted',
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert initial data
INSERT INTO users (username, email, password_hash, first_name, last_name, full_name, role) VALUES
('admin', 'admin@company.com', '$2b$10$hash_for_admin123', 'Admin', 'User', 'Admin User', 'admin'),
('employee', 'employee@company.com', '$2b$10$hash_for_employee123', 'Employee', 'User', 'Employee User', 'employee')
ON CONFLICT (username) DO NOTHING;

INSERT INTO categories (name, description) VALUES
('Engineering', 'Software development and technical roles'),
('Marketing', 'Marketing and promotion roles'),
('Sales', 'Sales and business development'),
('HR', 'Human resources and people operations'),
('Finance', 'Financial and accounting roles'),
('Operations', 'Operations and logistics')
ON CONFLICT DO NOTHING;